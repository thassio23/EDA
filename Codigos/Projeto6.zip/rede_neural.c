// Lucas Lopes 150137290
// Thassio Santos 140163697
// Victor Tavares 130136492
// Para executar este arquivo � necess�rio utilizar -lm
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

int *OrdemAleatoria(){ // Cria um vetor de 50 posi��es com valores que v�o de 1 at� 50 e permuta esses valores de forma aleat�ria para que valores entre 1 e 50 possam ser utilizados de forma aleat�ria
    char *nomeasfalto;
    char *stringdovalor;
    stringdovalor = malloc(2*sizeof(char));
    int *inicializa = malloc(50*sizeof(int));

    for (int i = 0; i < 50; i++) {
        inicializa[i] = i;
    }
    for (int i = 0; i < 50; i++) {
        int temp = inicializa[i];
        int aleatorio = rand() % 50;
        inicializa[i] = inicializa[aleatorio];
        inicializa[aleatorio] = temp;
    }
    return inicializa;
}

double num_aleatorio(){

    double aleatorio = (rand() % 80) - 40;
    return aleatorio;

}

double calcula_derivada(double n){      //Calcula a derivada de 1/(1+e^(-x))

    double derivada;
    double numerador;
    double denominador;
    numerador = pow(2.71828182, (-1)*n);     
    denominador = 1 + pow(2.71828182, (-1)*n);
    derivada = numerador / pow(denominador, 2);

    return derivada;
}

double neuronio(double* entradas, double* pesos, double deslocamentos, int numero_de_neuronios){ // Faz o c�lculo do neuronio

    double Campo_local_induzido = 0;
    double Ativacao_logistica = 0;

    int i;

    for(i = 0; i < numero_de_neuronios; i ++){
        Campo_local_induzido = Campo_local_induzido + (entradas[i] * pesos[i]); // C�lculo do campo local induzido
    }

    Campo_local_induzido = Campo_local_induzido + deslocamentos;

    Ativacao_logistica = 1 / (1 + pow(2.71828182, (-1)*Campo_local_induzido)); // Calculo da ativa��o. 2.71828182 = e(numero de euler)

    return Ativacao_logistica;

}


int main(int argc, char *argv[])
{

    if(argc == 1){
    printf("Insira argumentos\n");
    return -1;
    }

    FILE *file;
    char nome[80];
    char valor[3];
    int i;
    int j;
    int o;
    int z;
    int p;
    time_t t;
    srand((unsigned) time(&t));

    // Definindo o tamanhos //

    int numero_de_neuronios_ocultos = atoi(argv[1]); // Converte para int o numero inserido pelo usuario

    double* entradas = (double*)malloc(sizeof(double)*537); // Define o numero de entradas igual ao de featerues(536) + Flag para definir se � asfalto ou frama durante treinamento

    double** entradas_grama = (double**)malloc(sizeof(double*)*50);
    for(i = 0; i<50;i++){
        entradas_grama[i] = (double*)malloc(sizeof(double)*537); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }

    double** entradas_asfalto = (double**)malloc(sizeof(double*)*50);
    for(i = 0; i<50;i++){
        entradas_asfalto[i] = (double*)malloc(sizeof(double)*537); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }


    double** pesos_entrada = (double**)malloc(sizeof(double*)*536);
    for(i = 0; i<536;i++){
        pesos_entrada[i] = (double*)malloc(sizeof(double)*536); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }

    double** pesos_entrada_para_oculta = (double**)malloc(sizeof(double*)*numero_de_neuronios_ocultos);
    for(i = 0; i<numero_de_neuronios_ocultos;i++){
        pesos_entrada_para_oculta[i] = (double*)malloc(sizeof(double)*536); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }

    double* pesos_camada_oculta_para_saida = (double*)malloc(sizeof(double)*numero_de_neuronios_ocultos); // Define a quantidade de pesos que ser�o criados para o neuronio da camada oculta
    double* deslocamentos_camada_entrada = (double*)malloc(sizeof(double)*536); // Define a quantidade de pesos que ser�o criados para o neuronio de entrada
    double* deslocamentos_camada_oculta = (double*)malloc(sizeof(double)*numero_de_neuronios_ocultos); // Define a quantidade de pesos que ser�o criados para os neuronios da camada oculta
    double* neuronios_camada_entrada = (double*)malloc(sizeof(double)*536); // Define o numero de neuronios presentes na camada de entrada
    double* neuronios_camada_oculta = (double*)malloc(sizeof(double)*numero_de_neuronios_ocultos); // Define o numero de neuronios presentes na camada oculta
    double neuronio_de_saida; // Cria o neuronio de saida

    // Carrega os valores //

    for(i = 0; i <50; i++){ // Pega os 50 vetores de grama que foram gerados pelo codigo do trabalho 2 e os armazena como entrada

       strcpy(nome, "grama/featgrama"); 
       sprintf(valor,"%d", i);
       strcat(nome, valor);
       strcat(nome, ".txt");
       file = fopen(nome, "r");
       if(file == NULL){
        printf("Coloque o arquivo no mesmo diret�rio das pastas d	as features\n");
        return -1;
       }
        for(j = 0; j <536; j++){
            fscanf(file, "%lf%*c", &entradas_grama[i][j]);
        }
    }

    for(i = 0; i <50; i++){ // Pega os 50 vetores de asfalto que foram gerados pelo codigo do trabalho 2 e os armazena como entrada

       strcpy(nome, "asfalto/featasfalto");
       sprintf(valor,"%d", i);
       strcat(nome, valor);
       strcat(nome, ".txt");
       file = fopen(nome, "r");
       if(file == NULL){
        printf("Coloque o arquivo no mesmo diret�rio das pastas das features\n");
        return -1;
       }
        for(j = 0; j <536; j++){
            fscanf(file, "%lf%*c", &entradas_asfalto[i][j]);
        }
    }

    for(i = 0; i<50;i++){
         entradas_grama[i][536] = 1; // Coloca no ultimo valor o indicativo de que � grama para ser utilizado durante treinamento
    }

    for(i = 0; i<50;i++){
         entradas_asfalto[i][536] = 0; // Coloca no ultimo valor o indicativo de que � asfalto para ser utilizado durante treinamento
    }

    for(i = 0; i <536; i++){
        for(j = 0; j<536; j++){
            pesos_entrada[i][j] = num_aleatorio();   // Inicia os valores dos pesos de entrada
        }
    }

    for(i = 0; i <numero_de_neuronios_ocultos; i++){
        for(j = 0; j<536; j++){
            pesos_entrada_para_oculta[i][j] = num_aleatorio();   // Inicia os valores dos pesos dos neuronios de entrada para camada oculta
        }
    }

    for(i = 0; i <numero_de_neuronios_ocultos; i++){
        pesos_camada_oculta_para_saida[i] = num_aleatorio();    // Inicia os valores dos pesos da camada oculta
    }

    for(i = 0; i <536; i++){
        deslocamentos_camada_entrada[i] = num_aleatorio();    // Inicia os valores dos deslocamentos da camada oculta
    }

    for(i = 0; i <numero_de_neuronios_ocultos; i++){
        deslocamentos_camada_oculta[i] = num_aleatorio();    // Inicia os valores dos deslocamentos da camada oculta
    }

    double deslocamento_saida = num_aleatorio(); // Inicia o valor do deslocamento da camada de saida

    // carrega os vetores 

    int* OrdenacaoAleatoriaAsfalto;
    int* OrdenacaoAleatoriaGrama;
    int* OrdemAleatoriaTreinamento;
    double somadosquadrados = 0;
    double MSE;
    double erro;
    double derivada_entrada[536];
    double derivada_oculta[536];
    double derivada_saida;
    double gradiente_saida;
    double soma_gradiente_oculta = 0;
    double gradiente_oculta[536];
    double gradiente_entrada[536];
    int Flag_ImagemGrama;
    int incr = 50;
    int contador = 0;

    double** entrada_treinamento = (double**)malloc(sizeof(double*)*50);
    for(i = 0; i<50;i++){
        entrada_treinamento[i] = (double*)malloc(sizeof(double)*537); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }                                                                 // Possui 537 valores pois o ultimo � uma flag pra dizer se � asfalto ou grama

    double** entrada_teste = (double**)malloc(sizeof(double*)*50);
    for(i = 0; i<50;i++){
        entrada_teste[i] = (double*)malloc(sizeof(double)*537); // Define a quantidade de pesos que ser�o criados para cada neuronio baseando-se no numero de neuronios presentes na camada oculta
    }

    OrdenacaoAleatoriaAsfalto = OrdemAleatoria();
    OrdenacaoAleatoriaGrama = OrdemAleatoria();
    OrdemAleatoriaTreinamento = OrdemAleatoria();

    for(i = 0; i<25;i++){
        entrada_treinamento[i] = entradas_grama[OrdenacaoAleatoriaGrama[i]]; // Carrega no treinamento entradas de grama aleatorias
    }

    for(i = 0; i<25;i++){
        entrada_treinamento[i+25] = entradas_asfalto[OrdenacaoAleatoriaAsfalto[i]]; // Carrega no treinamento entradas de asfalto aleatorias
    }

    for(i = 0; i<25;i++){
        entrada_teste[i] = entradas_grama[OrdenacaoAleatoriaGrama[i+25]]; // Carrega no teste entradas de grama aleatorias
    }

    for(i = 0; i<25;i++){   
        entrada_teste[i+25] = entradas_asfalto[OrdenacaoAleatoriaAsfalto[i+25]]; // Carrega no teste entradas de asfalto aleatorias
    }

// Treinamento
    int epoca = 0;
	for(p = 0; p<1000;p++){
		OrdemAleatoriaTreinamento = OrdemAleatoria(); // Embaralha de forma aleat�ria a ordem do conjunto de elementos de entrada
	    for(z = 0; z<50;z++){ // Treina com os 50 vetores 1000 vezes ou quando o erro for menor que 0.2


			entradas = entrada_treinamento[OrdemAleatoriaTreinamento[z]]; // Recebe vetores que foram separados para treinamento

			Flag_ImagemGrama = entradas[536]; // Recebe valor na flag indicando qual � o tipo da imagem para poder treinar o neuronio de forma assistida

			for(i = 0; i <536; i++){
			    neuronios_camada_entrada[i] = neuronio(entradas, pesos_entrada[i],deslocamentos_camada_entrada[i],536); // Faz as contas dos neuronios na camada de entrada
			}


			for(i = 0; i <numero_de_neuronios_ocultos; i++){
			    neuronios_camada_oculta[i] = neuronio(neuronios_camada_entrada, pesos_entrada_para_oculta[i],deslocamentos_camada_oculta[i], numero_de_neuronios_ocultos); //  Faz as contas dos neuronios na camada oculta
			}

			neuronio_de_saida = neuronio(neuronios_camada_oculta,pesos_camada_oculta_para_saida,deslocamento_saida, 1); // Calcula o novo valor de sa�da do neuronio

			if(Flag_ImagemGrama == 1){ // Flag que indica que a imagem � grama (1) ou n�o (0)
			erro =  1 - neuronio_de_saida; // Se for grama (Flag = 1), o valor desejado para o c�lculo do erro � 1
			for(i = 0;i<536;i++){
			entradas[i] = 1;
			}
			}
			else{
			erro =  (-1)*neuronio_de_saida; // Se for asfalto (Flag = 0), o valor desejado para o c�lculo do erro � 0
			for(i = 0;i<536;i++){
			entradas[i] = 0;
			}       
			}

			for(i = 0; i < 536 ; i++){
			    derivada_entrada[i] = calcula_derivada(neuronios_camada_entrada[i]); // Calcula as derivadas dos valores dos neuronios na camada de entrada
			}

			for(i = 0; i < numero_de_neuronios_ocultos ; i++){
			    derivada_oculta[i] = calcula_derivada(neuronios_camada_oculta[i]); // Calcula as derivadas dos valores dos neuronios na camada oculta
			}

			derivada_saida = calcula_derivada(neuronio_de_saida); // Calcula as derivadas dos valores dos neuronios na camada de saida
			
			gradiente_saida = derivada_saida*erro; // Calcula o gradiente de saida
			 
			for(i = 0; i < numero_de_neuronios_ocultos ; i++){
			    gradiente_oculta[i] = derivada_oculta[i] * gradiente_saida * pesos_camada_oculta_para_saida[i]; // Calcula o gradiente da camada oculta
			}

			for(i = 0; i < 536 ; i++){
			    for(j = 0; j < numero_de_neuronios_ocultos;j++){
				for(o = 0; o < 536;o++){
				    soma_gradiente_oculta = soma_gradiente_oculta + (gradiente_oculta[j] * pesos_entrada_para_oculta[j][o]); // Calcula a soma dos gradientes da camada oculta * os pesos da camada oculta
				}
			    }            
			    gradiente_entrada[i] = derivada_entrada[i] * soma_gradiente_oculta; // Faz o calculo do gradiente de entrada
			    
			}
			    soma_gradiente_oculta = 0;

			deslocamento_saida =  deslocamento_saida + 2.0 * 0.1 * 1.0 * gradiente_saida; // Atualiza deslocamento de sa�da

			for(i = 0; i <536; i++){
			    deslocamentos_camada_entrada[i] =  deslocamentos_camada_entrada[i] + (2.0 * 0.1 * 1.0 * gradiente_entrada[i]); // Atualiza deslocamento na camada de entrada
			}

			for(i = 0; i <numero_de_neuronios_ocultos; i++){
			    deslocamentos_camada_oculta[i] =  deslocamentos_camada_oculta[i] + (2.0 * 0.1 * 1.0 * gradiente_oculta[i]); // Atualiza deslocamento na camada oculta
			}

			for(i = 0; i <numero_de_neuronios_ocultos; i++){
			   pesos_camada_oculta_para_saida[i] = pesos_camada_oculta_para_saida[i] + (2.0 * 0.1 * neuronios_camada_oculta[i] * gradiente_saida); // Atualiza pesos da camada oculta para saida
			}

			for(i = 0; i <numero_de_neuronios_ocultos; i++){
			    for(j = 0; j<536; j++){
				pesos_entrada_para_oculta[i][j] = pesos_entrada_para_oculta[i][j] + (2.0 * 0.1 * neuronios_camada_entrada[i] * gradiente_oculta[i]);   // Atualiza pesos da entrada para a oculta
			    }
			}

			for(i = 0; i <536; i++){
			    for(j = 0; j<536; j++){
				pesos_entrada[i][j] = pesos_entrada[i][j] + (2.0 * 0.1 * entradas[i] * gradiente_entrada[i]);   // Atualiza pesos da entrada
			    }
			}

			somadosquadrados = somadosquadrados + pow(erro, 2); // faz a soma dos erros quadraticos
			

	    }
		MSE = somadosquadrados/50; // calcula MSE
		somadosquadrados = 0;
		printf("MSE: %lf\n", MSE);
		if(MSE < 0.2){  // Se o erro for menor que 0.2 sai do treinamento
		    break;
		}
		printf("epoca: %d\n", epoca);
		epoca++;
	}

    // Testes

    double acertos_grama = 0;
    double falsos_erros = 0;
    double acertos_asfalto = 0;
    double falsos_acertos = 0;

    for(z = 0; z<50; z++){
             

    entradas = entrada_teste[z]; // Recebe o vetor com entradas que foram separadas para teste

        for(i = 0; i <536; i++){
            neuronios_camada_entrada[i] = neuronio(entradas, pesos_entrada[i],deslocamentos_camada_entrada[i],536); // Faz as contas dos neuronios na camada de entrada
        }


        for(i = 0; i <numero_de_neuronios_ocultos; i++){
            neuronios_camada_oculta[i] = neuronio(neuronios_camada_entrada, pesos_entrada_para_oculta[i],deslocamentos_camada_oculta[i], numero_de_neuronios_ocultos); //  Faz as contas dos neuronios na camada oculta
        }

        neuronio_de_saida = neuronio(neuronios_camada_oculta,pesos_camada_oculta_para_saida,deslocamento_saida, 1); // Calcula o novo valor de sa�da do neuronio

        if(z<25){

            if(neuronio_de_saida > 0.5){
                acertos_grama = acertos_grama + 1;  // Se identificar como grama, incrementa o contador de acerto
            }else{
                falsos_erros = falsos_erros + 1;    // Se identificar como asfalto, incrementa o contador de falso erro
            }

        }else{


            if(neuronio_de_saida <= 0.5){
                acertos_asfalto = acertos_asfalto + 1;  // Se identificar como asfalto, incrementa o contador de acerto
            }else{
                falsos_acertos = falsos_acertos + 1; // Se identificar como grama, incrementa o contador de falso acerto
            }

        }
    }

    // prints finais // 

    double taxa_de_acerto;
    double taxa_de_falsa_aceitacao;
    double taxa_de_falsa_rejeicao;

    printf("Acertos de grama: %lf\n", acertos_grama);
    printf("Acertos asfalto: %lf\n", acertos_asfalto);
    printf("Falsos acertos: %lf\n", falsos_acertos);
    printf("Falsos erros %lf\n", falsos_erros);
    printf("epoca: %d\n", epoca);


    taxa_de_acerto = 100*(acertos_grama/50 + acertos_asfalto/50);

    taxa_de_falsa_rejeicao = (falsos_erros/25)*100;

    taxa_de_falsa_aceitacao = (falsos_acertos/25)*100;

    printf("Taxa de acerto: %lf%%\n", taxa_de_acerto);
    printf("Taxa de falsa aceitacao: %lf%%\n", taxa_de_falsa_aceitacao);
    printf("Taxa de falsa rejeicao: %lf%%\n", taxa_de_falsa_rejeicao);

    
    return 0;

}
