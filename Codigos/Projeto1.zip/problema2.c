//Thássio Gabriel Farias dos Santos 140163697

#include <stdio.h>
#include <stdlib.h>
int *recebe_notas(float*, int);

int *conta_notas(int *, int);

int *percent_aprov(int*);

void main(){
    
    int *recebe;
    int APR[10];
    float a[10];
    int numero_de_elementos = 10;

    printf("Insira as notas\n");
    for(int i=0;i<10;i++){
    scanf("%f", &a[i]);
    }

    recebe = recebe_notas(a,numero_de_elementos);
    
    for(int i=0;i<10;i++){
        APR[i] = *(recebe+i);
    }

    recebe = conta_notas(APR,numero_de_elementos);
    
    printf("A quantidade de alunos aprovados é de: %d\n", recebe[0]);
    printf("A quantidade de alunos reprovados é de: %d\n", recebe[1]);

    recebe = percent_aprov(recebe);
    
    printf("A porcentagem de alunos aprovados é de: %d%%\n", recebe[0]);
    printf("A porcentagem de alunos reprovados é de: %d%%\n", recebe[1]);
    
    if(recebe[0] == 100){
    printf("Todo mundo foi aprovado\n");  
    }
    else if(recebe[0] > 50 && recebe[0] != 100){
    printf("Mais que a metade da turma foi aprovada\n");    
    }
    else if(recebe[0] == 50){
    printf("Metade da turma foi aprovada\n");
    }
    else if(recebe[0] <50 && recebe[0] != 0){
    printf("Menos da metade da turma foi aprovada\n");    
    }else{
    printf("Ninguém foi aprovado\n");   
    }

}

int *recebe_notas(float* NOTAS, int numero_de_elementos){
int *APR = (int*)malloc(numero_de_elementos*sizeof(int));
int i;
for(i = 0;i<numero_de_elementos;i++){
    if(*(NOTAS+i) >= 6){
    APR[i] = 1;
    }
    else{
    APR[i] = 0;
    }
}
    return APR;
}

int *conta_notas(int *APR, int numero_de_elementos){
    
    int *envia = (int*)malloc(2*sizeof(int));
    int aprovados = 0;
    int reprovados = 0;
    
    for(int i = 0;i < numero_de_elementos;i++){
        
    if(*(APR+i) == 1){
    aprovados++;
    }
    else{
    reprovados++;
    }
    }
    
    *(envia) = aprovados;
    *(envia + 1) = reprovados;
   
    return envia;
}

int *percent_aprov(int* porcentagem){


int preprovados,paprovados;
int i;


paprovados = *(porcentagem)*10;
preprovados = *(porcentagem + 1)*10;


*(porcentagem) = paprovados;
*(porcentagem+1) = preprovados;

return porcentagem;

}
