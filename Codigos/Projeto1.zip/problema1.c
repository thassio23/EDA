//Thássio Gabriel Farias dos Santos 140163697

#include <stdio.h>
#include <stdlib.h>

int *fneuronio(int*,int*,int*,int*);

void main(){
int tamanho = 10;
int entradas[tamanho];
int pesos[tamanho];
int limiar;
int i;
int *recebeponteiro;


printf("Insira os Valores de entrada:");

for(i=0;i<tamanho;i++){
scanf("%d", &entradas[i]);
}

printf("Insira os Valores de peso:");

for(i=0;i<tamanho;i++){
scanf("%d", &pesos[i]);
}

printf("Insira o valor do limiar:");

scanf("%d", &limiar);

recebeponteiro = fneuronio(entradas,pesos, &limiar,&tamanho);

printf("O valor do ponteiro retornado: %d\n", *recebeponteiro);

if(*recebeponteiro == 1){
    printf("Neuronio Ativado!\n");
}
else{
    printf("Neuronio Desativado!\n");
}

}


int *fneuronio(int* entradas,int* pesos,int* limiar, int* tamanho){

int somap = 0;
int *recebeponteiro;

recebeponteiro = (int*)malloc(sizeof(int));
for(int i = 0;i<*tamanho;i++){
 somap = somap + (*(entradas+i)) * (*(pesos+i));
}
 printf("O Valor de SOMAP : %d\n", somap);
 printf("O Valor do Limiar : %d\n", *limiar);

 if(somap > *limiar){
 *recebeponteiro = 1;
 }
 
 if(somap <= *limiar){
 *recebeponteiro = 0;
 }
 return recebeponteiro;
}
