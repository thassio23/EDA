//Thássio Gabriel Farias dos Santos 140163697

#include <stdio.h>
#include <stdlib.h>


void hanoi(int,char,char,char);

void main(){
	
    int quantidade;
    printf("Insira a quantidade de discos: ");
	scanf("%d", &quantidade);

	hanoi(quantidade,'a','b','c');
}

//Utilização deste algoritmo
//Mover disco da torre a para torre b
//Mover disco da torre a para torre c
//Mover disco da torre b para torre c

void hanoi(int n, char origem, char auxiliar, char final){

if (n == 1)
{
printf("Mover disco da torre %c para torre %c\n", origem, final); //Mover disco da torre a para torre b // Mover disco da torre b para torre c
return;
}
    hanoi(n-1, origem, final, auxiliar);
    printf("Mover disco da torre %c para torre %c\n", origem, final);//Mover disco da torre a para torre c
    hanoi(n-1, auxiliar, origem, final);
}
